
function back(){
  if(window.location.href.includes("moa.html")){
    window.location.href = '../../index.html';
  }
}
